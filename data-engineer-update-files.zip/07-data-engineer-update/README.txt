DATA ENGINEER — an update to your products.json (please read)
=================================================================

What's in this folder:
- products.json

Where it goes in the repo:
  products.json  (repo root — replaces the current file)

WHAT CHANGED AND WHY
-----------------------
The Catalog Builder was previously hardcoding a lookup table inside their
own JavaScript file, mapping each product name to an image filename. That
worked, but it put data (image filenames) inside code, which isn't
where it belongs — same reasoning as why products live in products.json
instead of hardcoded HTML in the first place.

So an "image" field was added to every product in this file, pointing to
the existing image files already sitting in frontend/assets/. No new
images were added — this just moves the filename mapping that already
existed into the data file where it's supposed to live.

Example of what changed, per product:
  Before: { "name": "Rice 50kg", "category": "Grains", "price": 36669.0 }
  After:  { "name": "Rice 50kg", "category": "Grains", "price": 36669.0,
            "image": "assets/rice 50kg.jpeg" }

WHAT YOU SHOULD DO
--------------------
Since you own the real data pipeline (the cleaning notebook), you'll
probably want to:
1. Add an "image" column to your cleaning notebook's product table, so
   this field is generated the same way as name/category/price, rather
   than living only in this one hand-edited file going forward
2. Match the filenames already sitting in frontend/assets/ — the mapping
   used here is included below so you can copy it into your notebook
   exactly as-is

Filename mapping used:
  Bread (loaf)         -> assets/Bread.jpeg
  Matches (box)        -> assets/box matches.jpeg
  Palm Oil 5L          -> assets/palm oil 5L.jpeg
  Beans (White)        -> assets/white beans.jpeg
  Plantain (bunch)     -> assets/plantain.jpeg
  Beans (Red)          -> assets/red beans.jpeg
  Maggi Cubes (pack)   -> assets/pack maggi.jpeg
  Tomato Paste (tin)   -> assets/tin tomatoes.jpeg
  Soap (bar)           -> assets/bar soap.jpeg
  Onions 1kg           -> assets/onion.jpeg
  Vegetable Oil 5L     -> assets/Vegetable Oil 5L.jpeg
  Salt 1kg             -> assets/salt 1 kg.jpeg
  Cassava (bag)        -> assets/cassava(bag).jpeg
  Sugar 1kg            -> assets/sugar 1kg.jpeg
  Rice 25kg            -> assets/rice 25kg.jpeg
  Rice 50kg            -> assets/rice 50kg.jpeg
  Detergent 1kg        -> assets/detergent 1kg.jpeg
  Palm Oil 1L          -> assets/palm oil 1L.jpeg
  Milk Powder 400g     -> assets/milk powder.jpeg
  Tomatoes 1kg         -> assets/tomato.jpeg

Until you fold this into the notebook, this hand-edited products.json is
fine to use as-is — just be aware it'll need re-syncing if you re-export
from the notebook later without this field included.
